package kr.ac.yuhan.cs.googlemaps;

import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private Marker fakeMarker;
    private LatLng fakeLocation = new LatLng(37.486375, 126.821070);
    private final double MOVE_UNIT = 0.00005; // 거리조절
    private Handler moveHandler = new Handler();
    private Runnable moveRunnable;
    private boolean isMoving = false;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.main);
        mapFragment.getMapAsync(this);

        Button btnUp = findViewById(R.id.btn_up);
        Button btnDown = findViewById(R.id.btn_down);
        Button btnLeft = findViewById(R.id.btn_left);
        Button btnRight = findViewById(R.id.btn_right);

        setupButtonRepeat(findViewById(R.id.btn_up), 0, MOVE_UNIT);
        setupButtonRepeat(findViewById(R.id.btn_down), 0, -MOVE_UNIT);
        setupButtonRepeat(findViewById(R.id.btn_left), -MOVE_UNIT, 0);
        setupButtonRepeat(findViewById(R.id.btn_right), MOVE_UNIT, 0);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        fakeMarker = mMap.addMarker(new MarkerOptions().position(fakeLocation).title("가짜 위치"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(fakeLocation, 17));
    }

    private void moveMarker(double dx, double dy) {
        if (mMap != null && fakeMarker != null) {
            double newLat = fakeMarker.getPosition().latitude + dy;
            double newLng = fakeMarker.getPosition().longitude + dx;
            fakeLocation = new LatLng(newLat, newLng);
            fakeMarker.setPosition(fakeLocation);
            mMap.moveCamera(CameraUpdateFactory.newLatLng(fakeLocation));
        }
    }

    private void setupButtonRepeat(View button, double dx, double dy) {
        button.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    isMoving = true;
                    moveRunnable = new Runnable() {
                        @Override
                        public void run() {
                            if (isMoving) {
                                moveMarker(dx, dy);
                                moveHandler.postDelayed(this, 100); // 0.1초 간격 반복
                            }
                        }
                    };
                    moveHandler.post(moveRunnable); // 즉시 실행
                    break;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    isMoving = false;
                    moveHandler.removeCallbacks(moveRunnable);
                    break;
            }
            return true;
        });
    }
}